package main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class HiloSimple2 implements Runnable {
	
	private int id;
	
	public HiloSimple2 (int id){
		
		this.id = id;
		
	}
	
    @Override
    public void run() {
        try {
        	
            // Se crea el archivo si no existe
            File file = new File("hilos.txt");


            PrintWriter writer = new PrintWriter(new FileWriter(file, true));
            
            // Se muestra por pantalla 
            System.out.println("El proceso " + id + " ha sido lanzado.");
            
            // Se escribe en el log
            writer.println("El proceso " + id + " ha sido lanzado.");

            writer.close();
            
        } catch (IOException e) {
        	
        	// Por si da error
        	System.out.println("Ha habido un error.");
        	
        }
        
    }
	
}