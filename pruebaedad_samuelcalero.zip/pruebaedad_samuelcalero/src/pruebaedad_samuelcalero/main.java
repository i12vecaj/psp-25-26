package pruebaedad_samuelcalero;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Aqui se implemente el escaner para permitir al usuario meter datos por consola
		Scanner sc = new Scanner(System.in);
		System.out.println("Hola, introduce tu nombre");
		String nombre = sc.nextLine();
		//Aqui una vez el usuario introduzca su edad se procede a hacer el calculo
		System.out.println("Ahora dime tu edad");
		int edad = sc.nextInt();
		int edadcalculada = 2125 - edad;
		//Finalmente se muestra el resultado
		System.out.println(nombre + ", Cumpliras 100 años en " + edadcalculada);
	}

}
