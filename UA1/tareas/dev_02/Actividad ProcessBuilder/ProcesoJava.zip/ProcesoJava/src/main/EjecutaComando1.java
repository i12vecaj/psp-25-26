package main;
import java.io.*;

public class EjecutaComando1 {

	public static void main(String[] args) throws IOException {

		Process p = new ProcessBuilder("ping", "google.com").start();

		InputStream is = p.getInputStream();

		int c;
		while ((c = is.read()) != -1)
			System.out.print((char) c);
		is.close();
		
	}

}