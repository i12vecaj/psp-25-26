package main;

import java.io.*;

public class EjecutaComando4 {

    public static void main(String[] args) throws IOException, InterruptedException {
       
    	String fichero = "salida2.txt";

        ProcessBuilder pb1 = new ProcessBuilder("cmd", "/c", "dir");
        pb1.redirectOutput(new File(fichero));
        
        Process p1 = pb1.start();
        p1.waitFor();


        ProcessBuilder pb2 = new ProcessBuilder("cmd", "/c", "type", fichero);
        Process p2 = pb2.start();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(p2.getInputStream()))) {
        	
            String linea;
            while ((linea = br.readLine()) != null) {
            	
                System.out.println(linea);
                
            }
            
        }
        
    }
    
}
