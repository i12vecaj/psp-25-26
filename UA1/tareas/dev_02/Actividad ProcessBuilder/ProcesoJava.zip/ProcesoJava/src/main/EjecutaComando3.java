package main;
import java.io.*;

public class EjecutaComando3 {

    public static void main(String[] args) throws IOException {

        Process p = new ProcessBuilder("ping", "google.com").start();

        InputStream is = p.getInputStream();
        String fichero = "salida.txt";        

        try (BufferedReader br = new BufferedReader(new InputStreamReader(is));
             BufferedWriter bw = new BufferedWriter(new FileWriter(fichero))) {

            String linea;
            while ((linea = br.readLine()) != null) {
            	
                System.out.println(linea);
                bw.write(linea);
                bw.newLine();
                
            }
            
        }

        is.close();
        
    }
    
}
