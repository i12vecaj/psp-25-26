package ex3psp;

import java.io.IOException;

public class Lanzador {
    public static void main(String[] args) throws InterruptedException {
        if (args.length < 1) {
            System.out.println("Error: Debes pasar un argumento para ejecutar el programa.");
            return;
        }

        try {
            ProcessBuilder pb = new ProcessBuilder("java", "Procesos", args[0]);
            pb.inheritIO();
            Process p = pb.start();
            int exitCode = p.waitFor();

            switch (exitCode) {
                case 0 -> System.out.println("El programa terminó correctamente (código 0).");
                case 1 -> System.out.println("Error: No se introdujo ningún argumento (código 1).");
                case 2 -> System.out.println("Error: El argumento no es un número entero (código 2).");
                case 3 -> System.out.println("Error: El número es menor que 0 (código 3).");
                default -> System.out.println("Error desconocido (código " + exitCode + ").");
            }

        } catch (IOException e) {
            System.out.println("Error al intentar ejecutar el programa: " + e.getMessage());
        }
    }
}

