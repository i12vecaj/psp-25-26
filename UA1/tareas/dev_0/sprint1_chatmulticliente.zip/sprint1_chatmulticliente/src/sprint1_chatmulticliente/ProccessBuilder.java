package sprint1_chatmulticliente;
import java.io.IOException;
public class ProccessBuilder {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//procesos de forma paralela
		ProcessBuilder pb = new ProcessBuilder("notepad.exe");
		ProcessBuilder pb2 = new ProcessBuilder("cmd.exe");
		ProcessBuilder pb3 = new ProcessBuilder("explorer.exe");
		
		pb.start();
		pb2.start();
		pb3.start();
		
	}

}
