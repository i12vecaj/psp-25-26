package sprint1_chatmulticliente;

import java.io.IOException;

public class ProccessBuilder2 {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		
		//procesos de forma secuencial
		
        ProcessBuilder pb1 = new ProcessBuilder("notepad.exe");
        Process p1 = pb1.start();
        System.out.println("Ejecutando notepad...");
        p1.waitFor();

        ProcessBuilder pb2 = new ProcessBuilder("calc.exe");
        Process p2 = pb2.start();
        System.out.println("Ejecutando calculadora...");
        p2.waitFor(); 

        ProcessBuilder pb3 = new ProcessBuilder("mspaint.exe");
        Process p3 = pb3.start();
        System.out.println("Ejecutando paint...");
        p3.waitFor(); 

        

	}

}
