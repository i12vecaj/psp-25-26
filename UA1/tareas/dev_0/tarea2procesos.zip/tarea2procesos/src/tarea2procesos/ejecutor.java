package tarea2procesos;

import java.io.IOException;


public class ejecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//En el try se crea y ejecuta el proceso que abre el main, que es el programa de los ejercicios FR1 Y FR2, mas abajo está el control de errores
		try {
			
			   Process pb = new ProcessBuilder("java", "main").start();
			
	            
		}catch(IOException e){
			
			 System.err.println("Error al ejecutar el proceso: " + e.getMessage());
			
		}
		
	}

}
