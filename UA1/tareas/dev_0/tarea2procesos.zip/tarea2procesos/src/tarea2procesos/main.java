package tarea2procesos;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//se crea las variables que van a almacenar el texto y el que la que lo va a leer
		StringBuilder texto = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.println("Introduce texto (finaliza con '*'):");
            //creamos el bucle con un read para leer lo que escriba el usuario, luego con un casting comprobamos si el usuario ha escrito *
            int caracter;
            while ((caracter = br.read()) != -1) {
                if ((char) caracter == '*') {
                    break; 
                }
                texto.append((char) caracter);
            }
            //aquí se muestra el texto escrito
            System.out.println("Texto introducido:");
            System.out.println(texto.toString());
            //aquí está el control de errores
        } catch (IOException e) {
            System.err.println("Error al leer datos: " + e.getMessage());
        }
		
	}

}
